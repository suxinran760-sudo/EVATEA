# EVA 茶研所

纯 WebView 外壳 + `app/src/main/assets/www` 网页内容（含新增「杯架」页）。

## 用 GitHub 打包 APK
1. 新建仓库，把本目录所有文件（包括隐藏的 `.github` 文件夹）上传到仓库根目录，分支为 main。
2. 打开仓库的 Actions 页面，等待 "Build APK" 跑完（也可手动 Run workflow）。
3. 在该次运行页面底部 Artifacts 下载 `EVA-tea-apk`，解压得到 `app-debug.apk`，即可安装。

## 修改网页
直接改 `app/src/main/assets/www` 下的 index.html / css / js 即可。
