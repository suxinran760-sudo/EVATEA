/* ===== EVA 茶研所 · 点单系统（离线单机版） ===== */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const app = $('#app');
const money = n => '¥' + (Math.round(n * 100) / 100);
const byId = id => PRODUCTS.find(p => p.id === id);
const h = html => { const t = document.createElement('template'); t.innerHTML = html.trim(); return t.content.firstElementChild; };

/* ---------- 图标 ---------- */
const ICONS = {
  home: '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/><path d="M10 20v-6h4v6"/>',
  cup: '<path d="M5 8h14l-1.5 12h-11z"/><path d="M4 8h16"/><path d="M13 8l2-5"/>',
  list: '<rect x="5" y="3" width="14" height="18" rx="1"/><path d="M9 8h6M9 12h6M9 16h4"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c1-5 5-7 8-7s7 2 8 7"/>',
  pin: '<path d="M12 22s7-6.5 7-12a7 7 0 10-14 0c0 5.5 7 12 7 12z"/><circle cx="12" cy="10" r="2.5"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>',
  bag: '<path d="M5 8h14l1 13H4z"/><path d="M9 8V6a3 3 0 016 0v2"/>',
  chev: '<path d="M9 5l7 7-7 7"/>',
  back: '<path d="M15 5l-7 7 7 7"/>',
  x: '<path d="M6 6l12 12M18 6L6 18"/>',
  ticket: '<path d="M3 7h18v4a2 2 0 000 4v4H3v-4a2 2 0 000-4z"/><path d="M14 7v12" stroke-dasharray="2 2"/>',
  music: '<path d="M9 18V5l11-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="17" cy="16" r="3"/>',
  image: '<rect x="3" y="4" width="18" height="16"/><circle cx="9" cy="10" r="2"/><path d="M3 18l6-5 4 3 3-3 5 5"/>',
  gift: '<rect x="3" y="9" width="18" height="12"/><path d="M12 9v12M3 13h18M12 9C8 9 7 4 10 4s2 5 2 5 0-5 2-5 3 5-2 5"/>',
  trash: '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>',
  bike: '<circle cx="6" cy="17" r="3"/><circle cx="18" cy="17" r="3"/><path d="M6 17l4-8h5l3 8M9 9H6"/>',
  speaker: '<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M16 9a4 4 0 010 6"/>',
  edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/>',
  shelf: '<path d="M4 20V7h3v13M9 20V4h3v16M14 20V7h3v13M19 20V9"/><path d="M3 20h18"/>',
};
const ic = (n, c = '') => `<svg class="ico ${c}" viewBox="0 0 24 24">${ICONS[n] || ''}</svg>`;

/* ---------- 状态 ---------- */
const KEY = 'eva_tea_v2';
const DEF = () => ({
  mode: 'pickup', store: 0, cart: [], orders: [], points: 320, seq: 72, nick: '式波·驾驶员', phone: '', bgm: false,
  coupons: [
    { id: 'c1', name: '新人立减券', desc: '满20元可用', min: 20, off: 5, exp: '2026-12-31', used: false },
    { id: 'c2', name: '鲜果茶专享券', desc: '满30元可用', min: 30, off: 8, exp: '2026-12-31', used: false },
    { id: 'c3', name: '无门槛小额券', desc: '全场通用', min: 0, off: 2, exp: '2026-12-31', used: false },
  ],
  addrs: [{ id: 'a1', name: '式波', phone: '13800000002', addr: '第三新东京市 NERV 本部 02号舱' }],
  addrSel: 'a1',
});
let S;
try { S = Object.assign(DEF(), JSON.parse(localStorage.getItem(KEY) || '{}')); } catch (e) { S = DEF(); }
const save = () => { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} };

/* ---------- 购物车计算 ---------- */
const lineUnit = l => { const p = byId(l.pid); return p.price + (p.simple ? 0 : SIZES[l.size || 0].p) + (l.tops || []).reduce((s, t) => s + TOPS[t].p, 0); };
const lineSpec = l => { const p = byId(l.pid); if (p.simple) return ''; return [SIZES[l.size || 0].n, p.temps[0] && l.temp, SUGARS[l.sugar], ...(l.tops || []).map(t => TOPS[t].n)].join(' / '); };
const cartCount = () => S.cart.reduce((s, l) => s + l.qty, 0);
const cartSub = () => S.cart.reduce((s, l) => s + lineUnit(l) * l.qty, 0);
const qtyOf = pid => S.cart.filter(l => l.pid === pid).reduce((s, l) => s + l.qty, 0);

function addLine(l) {
  const ex = S.cart.find(x => x.key === l.key);
  if (ex) ex.qty += l.qty; else S.cart.push(l);
  save(); refreshAll();
}
function changeQty(key, d) {
  const i = S.cart.findIndex(l => l.key === key); if (i < 0) return;
  S.cart[i].qty += d; if (S.cart[i].qty <= 0) S.cart.splice(i, 1);
  save(); refreshAll();
}

/* ---------- 浮层管理 ---------- */
const stack = [];
function openSheet(html, { onMount } = {}) {
  const bd = h('<div class="backdrop"></div>'), sh = h(`<div class="sheet">${html}</div>`);
  app.append(bd, sh);
  requestAnimationFrame(() => requestAnimationFrame(() => { bd.classList.add('show'); sh.classList.add('show'); }));
  const api = { el: sh, close() {
    if (api.closed) return; api.closed = true;
    const i = stack.indexOf(api); if (i >= 0) stack.splice(i, 1);
    bd.classList.remove('show'); sh.classList.remove('show');
    setTimeout(() => { bd.remove(); sh.remove(); }, 270);
  } };
  bd.onclick = api.close;
  const x = $('.sh-x', sh); if (x) x.onclick = api.close;
  stack.push(api); onMount && onMount(sh, api); return api;
}
function openOv(title, body, { footer = '', onMount, onClose } = {}) {
  const ov = h(`<div class="ov"><div class="ov-h"><button class="back">${ic('back')}</button><span>${title}</span></div><div class="ov-b">${body}</div>${footer ? `<div class="ov-f">${footer}</div>` : ''}</div>`);
  app.append(ov);
  requestAnimationFrame(() => requestAnimationFrame(() => ov.classList.add('show')));
  const api = { el: ov, body: $('.ov-b', ov), close() {
    if (api.closed) return; api.closed = true;
    const i = stack.indexOf(api); if (i >= 0) stack.splice(i, 1);
    ov.classList.remove('show'); onClose && onClose();
    setTimeout(() => ov.remove(), 290);
  } };
  $('.back', ov).onclick = api.close;
  stack.push(api); onMount && onMount(ov, api); return api;
}
function closeAll() { [...stack].reverse().forEach(a => a.close()); }
let lb = null;
function lightbox(src) {
  lb = h(`<div class="lb"><img src="${src}"></div>`); app.append(lb);
  lb.onclick = () => { lb.remove(); lb = null; };
}
window.__back = () => {
  if (lb) { lb.remove(); lb = null; return true; }
  if (stack.length) { stack[stack.length - 1].close(); return true; }
  if (curTab !== 'home') { go('home'); return true; }
  return false;
};
let toastT;
function toast(m) { const t = $('#toast'); t.textContent = m; t.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('show'), 1800); }

/* ---------- 路由 / 底栏 ---------- */
const TABS = [['home', '首页', 'home'], ['menu', '点单', 'cup'], ['shelf', '杯架', 'shelf'], ['orders', '订单', 'list'], ['me', '我的', 'user']];
let curTab = 'home';
function renderTabbar() {
  const live = S.orders.filter(o => stageOf(o) >= 0 && stageOf(o) < 3).length;
  $('#tabbar').innerHTML = TABS.map(t => `<button class="tab ${t[0] === curTab ? 'on' : ''}" data-t="${t[0]}">${ic(t[2])}<span>${t[1]}</span>${t[0] === 'orders' && live ? `<i class="dot">${live}</i>` : ''}</button>`).join('');
  $$('#tabbar .tab').forEach(b => b.onclick = () => go(b.dataset.t));
}
function go(t) {
  curTab = t;
  $$('.page').forEach(p => p.classList.toggle('on', p.id === 'page-' + t));
  if (t === 'home') renderHome();
  if (t === 'orders') renderOrders();
  if (t === 'me') renderMe();
  if (t === 'menu') { updateSeg(); updateCartBar(); }
  if (t === 'shelf') renderShelf();
  renderTabbar();
}
function refreshAll() {
  updateCartBar(); updateActs(); renderTabbar();
}

/* ---------- 等级 ---------- */
const LEVELS = [{ n: '见习驾驶员', min: 0 }, { n: '正式驾驶员', min: 500 }, { n: '王牌驾驶员', min: 1500 }, { n: 'EVA 传说', min: 3500 }];
function levelOf(pts) {
  let i = 0; LEVELS.forEach((l, k) => { if (pts >= l.min) i = k; });
  const cur = LEVELS[i], nx = LEVELS[i + 1];
  return { name: cur.n, pct: nx ? Math.round((pts - cur.min) / (nx.min - cur.min) * 100) : 100, next: nx ? nx.min - pts : 0 };
}

/* ================= 首页 ================= */
let bnTimer;
function renderHome() {
  const lv = levelOf(S.points), coupons = S.coupons.filter(c => !c.used).length;
  const pg = $('#page-home');
  pg.innerHTML = `
  <div class="hd"><img class="sig" src="img/sig.png" alt="Asuka">
    <div style="display:flex;gap:8px">
      <button class="pill" id="hBgm">${ic('speaker')}<span>${S.bgm ? 'BGM 开' : 'BGM 关'}</span></button>
      <button class="pill" id="hStore">${ic('pin')}<span>${STORES[S.store].n}</span></button>
    </div></div>
  <div class="banner"><div class="bn-track" id="bnTrack">${BANNERS.map((b, i) => `
    <div class="bn" data-go="${b.go}"><img src="${b.img}" style="object-position:${b.pos}" alt=""><div class="bn-cap"><b>${b.t}</b><span>${b.s}</span></div></div>`).join('')}</div>
    <div class="bn-dots" id="bnDots">${BANNERS.map((b, i) => `<i class="${i ? '' : 'on'}"></i>`).join('')}</div></div>
  <div class="modes">
    <button class="mode panel inv" data-mode="pickup">${ic('cup')}<b>到店自取</b><small>PICK UP</small><span>提前下单 免排队<br>到店出示取餐码</span></button>
    <button class="mode panel" data-mode="delivery">${ic('bike')}<b>外卖配送</b><small>DELIVERY</small><span>送到你的驾驶舱<br>满¥40免配送费</span></button>
  </div>
  <div class="id-card panel">
    <div class="ph"><img src="img/asuka-bw.jpg" alt=""><b>PILOT</b></div>
    <div class="bd"><div class="lv">${lv.name}</div><div class="nm">${S.nick}</div>
      <div class="stats"><div><b>${S.points}</b>积分</div><div><b>${coupons}</b>优惠券</div><div><b>${S.orders.length}</b>订单</div></div>
      <div class="bar"><i style="width:${lv.pct}%"></i></div>
      <div class="bar-t"><span>同步率 ${lv.pct}%</span><span>${lv.next ? '距下一级 ' + lv.next + ' 分' : '已满级'}</span></div></div>
  </div>
  <div class="quote">The world is not kind.<br>But I'm still here.<small>— 惣流·アスカ·ラングレー</small></div>
  <div class="sec"><div class="sec-t"><b>人气爆款</b><i>HOT PICKS</i></div>
    <div class="hscroll">${PRODUCTS.filter(p => p.hot).map(p => `<button class="hcard" data-p="${p.id}"><div class="tile">${visual(p)}</div><b>${p.name}</b><span>${money(p.price)}</span></button>`).join('')}</div></div>
  <div class="sec"><div class="sec-t"><b>影像档案</b><i>ARCHIVE</i></div>
    <div class="video"><video src="media/hero.mp4" poster="img/asuka-red.jpg" muted loop playsinline autoplay></video></div></div>
  <div class="foot">个人自用练习项目 · 非商业用途<br>EVANGELION © khara / GAINAX</div>`;

  $('#hBgm').onclick = () => setBgm(!S.bgm);
  $('#hStore').onclick = pickStore;
  $$('.mode', pg).forEach(b => b.onclick = () => { S.mode = b.dataset.mode; save(); go('menu'); });
  $$('.bn', pg).forEach(b => b.onclick = () => { const g = b.dataset.go; g === 'menu' ? go('menu') : openProduct(g); });
  $$('.hcard', pg).forEach(b => b.onclick = () => openProduct(b.dataset.p));
  const tr = $('#bnTrack'), dots = $$('#bnDots i');
  tr.onscroll = () => { const i = Math.round(tr.scrollLeft / tr.clientWidth); dots.forEach((d, k) => d.classList.toggle('on', k === i)); };
  clearInterval(bnTimer);
  bnTimer = setInterval(() => {
    if (curTab !== 'home' || !tr.isConnected) return;
    const i = (Math.round(tr.scrollLeft / tr.clientWidth) + 1) % BANNERS.length;
    tr.scrollTo({ left: i * tr.clientWidth, behavior: 'smooth' });
  }, 4500);
  const v = $('video', pg); if (v) v.play().catch(() => {});
}

function pickStore() {
  openSheet(`<button class="sh-x">${ic('x')}</button><div class="sh-h">选择门店</div><div class="sh-b">${STORES.map((s, i) => `
    <button class="cp ${i === S.store ? 'sel' : ''}" data-i="${i}" style="display:block;padding:12px 14px"><b style="font-size:15px;font-weight:900">${s.n}</b><small style="display:block;font-size:12px;color:#8b8880;margin-top:3px">${s.addr}</small><small style="display:block;font-size:11px;color:#8b8880">距您 ${s.dist} · 营业 ${s.time}</small></button>`).join('')}</div>`, {
    onMount: (el, api) => $$('.cp', el).forEach(b => b.onclick = () => { S.store = +b.dataset.i; save(); api.close(); renderMenu(); if (curTab === 'home') renderHome(); toast('已切换到 ' + STORES[S.store].n); })
  });
}

/* ================= 点单页 ================= */
let spyLock = false;
function actHTML(p) {
  const q = qtyOf(p.id);
  if (p.simple) return q
    ? `<div class="stepper"><button data-minus="${p.id}">−</button><span>${q}</span><button class="plus" data-plus="${p.id}">+</button></div>`
    : `<button class="padd" data-plus="${p.id}">加入</button>`;
  return `<button class="padd" data-open="${p.id}">选规格${q ? `<span class="cnt">${q}</span>` : ''}</button>`;
}
function prodHTML(p) {
  return `<div class="prod" data-id="${p.id}"><div class="tile">${visual(p)}</div>
    <div class="pinfo"><div class="pname">${p.name}${p.tag ? `<span class="ptag">${p.tag}</span>` : ''}</div>
    <div class="pjp">${p.jp}</div><div class="pdesc">${p.desc}</div>
    <div class="pbot"><div class="price"><small>¥</small>${p.price}${p.orig ? `<s>¥${p.orig}</s>` : ''}</div><div class="acts-area" data-a="${p.id}">${actHTML(p)}</div></div></div></div>`;
}
function renderMenu() {
  const st = STORES[S.store], pg = $('#page-menu');
  pg.innerHTML = `
  <div class="m-top"><button class="m-store" id="mStore"><b>${ic('pin', 's14')}<span>${st.n}</span>${ic('chev', 's14')}</b><small>距您 ${st.dist} · 营业 ${st.time}</small></button>
    <div class="seg" id="mSeg"><button data-m="pickup">自取</button><button data-m="delivery">外卖</button></div>
    <button class="m-search" id="mSearch">${ic('search')}</button></div>
  <div class="m-body"><div class="m-nav" id="mNav">${CATS.map((c, i) => `<button data-c="${c.id}" class="${i ? '' : 'on'}">${c.n}<small>${c.jp}</small></button>`).join('')}</div>
    <div class="m-list" id="mList">
      <div class="promo"><img src="img/asuka-bw.jpg" alt=""><div><b>新人首单立减 ¥5</b><span>已发放至「我的 · 优惠券」</span></div></div>
      ${CATS.map(c => `<div class="cat-h" id="sec-${c.id}"><b>${c.n}</b><i>${c.jp}</i></div>${PRODUCTS.filter(p => c.id === 'hot' ? p.hot : p.cat === c.id).map(prodHTML).join('')}`).join('')}
      <div class="foot">— 已经到底啦 —</div></div></div>
  <div class="cartbar" id="cartbar"></div>`;
  $('#mStore').onclick = pickStore;
  $('#mSearch').onclick = openSearch;
  $$('#mSeg button').forEach(b => b.onclick = () => { S.mode = b.dataset.m; save(); updateSeg(); updateCartBar(); });
  const list = $('#mList');
  $$('#mNav button').forEach(b => b.onclick = () => {
    const sec = $('#sec-' + b.dataset.c); spyLock = true; list.scrollTo({ top: sec.offsetTop - 2 });
    setNav(b.dataset.c); setTimeout(() => spyLock = false, 800);
  });
  list.onscroll = () => {
    if (spyLock) return;
    let cur = CATS[0].id;
    CATS.forEach(c => { if ($('#sec-' + c.id).offsetTop - 30 <= list.scrollTop) cur = c.id; });
    if (list.scrollTop + list.clientHeight >= list.scrollHeight - 4) cur = CATS[CATS.length - 1].id;
    setNav(cur);
  };
  list.onclick = e => bindProdClick(e);
  updateSeg(); updateCartBar();
}
function setNav(id) { $$('#mNav button').forEach(b => b.classList.toggle('on', b.dataset.c === id)); }
function bindProdClick(e) {
  const t = e.target.closest('[data-plus],[data-minus],[data-open],.prod'); if (!t) return;
  if (t.dataset.plus) { const p = byId(t.dataset.plus); addLine({ key: p.id, pid: p.id, qty: 1 }); return; }
  if (t.dataset.minus) { changeQty(t.dataset.minus, -1); return; }
  const id = t.dataset.open || t.closest('.prod').dataset.id;
  const p = byId(id); if (p.simple) return; openProduct(id);
}
function updateSeg() { $$('#mSeg button').forEach(b => b.classList.toggle('on', b.dataset.m === S.mode)); }
function updateActs() { $$('.acts-area').forEach(a => { const p = byId(a.dataset.a); a.innerHTML = actHTML(p); }); }
function updateCartBar() {
  const bar = $('#cartbar'); if (!bar) return;
  const n = cartCount(), sub = cartSub();
  bar.classList.toggle('off', !n);
  bar.innerHTML = `<div class="bag" id="cbBag">${ic('bag')}${n ? `<i>${n}</i>` : ''}</div>
    <div class="sum" id="cbSum">${n ? `<b>${money(sub)}</b><small>${S.mode === 'delivery' ? (sub >= 40 ? '已免配送费' : '另需配送费 ¥3 · 满¥40免') : '到店自取 · 免配送费'}</small>` : `<b>未选购商品</b>`}</div>
    <button class="go" id="cbGo">去结算</button>`;
  $('#cbBag').onclick = $('#cbSum').onclick = () => n && openCart();
  $('#cbGo').onclick = () => openCheckout();
}


/* ---------- 立体杯架（3D 翻看） ---------- */
let shIdx = 0, shCat = 'all', shReady = false;
const shList = () => PRODUCTS.filter(p => shCat === 'all' || p.cat === shCat);
const catName = id => (CATS.find(c => c.id === id) || {}).n || '';
function shCard(p, i) {
  const no = String(i + 1).padStart(3, '0');
  return `<div class="sh-item" data-i="${i}"><div class="sh-card">
    <div class="sh-no">NO.${no}</div>
    <div class="sh-art">${visual(p)}</div>
    <div class="sh-spine">${p.name.split('·').pop()}</div>
    <div class="sh-pr">¥${p.price}</div></div></div>`;
}
function renderShelf() {
  const pg = $('#page-shelf'), list = shList();
  if (shIdx >= list.length) shIdx = 0;
  pg.innerHTML = `
  <div class="sh-hd"><div class="sh-h1">杯架<small>04 / CUP SHELF</small></div><button class="pill" id="shSearch">${ic('search')}</button></div>
  <div class="sh-sub"><span>COLLECTION / MENU</span><i></i></div>
  <div class="sh-title">立体杯架</div>
  <div class="sh-tool">
    <label class="sh-sel">${ic('cup')}<select id="shCat"><option value="all">全部奶茶</option>${CATS.filter(c => c.id !== 'hot').map(c => `<option value="${c.id}" ${c.id === shCat ? 'selected' : ''}>${c.n}</option>`).join('')}</select></label>
    <span class="sh-cnt">${list.length} 杯</span>
  </div>
  <div class="sh-stage" id="shStage"><div class="sh-floor"></div>${list.map(shCard).join('')}</div>
  <div class="sh-info" id="shInfo"></div>
  <div class="sh-pager"><button id="shPrev" aria-label="上一杯">‹</button><span id="shNum"></span><button id="shNext" aria-label="下一杯">›</button></div>`;
  $('#shSearch').onclick = openSearch;
  $('#shCat').onchange = e => { shCat = e.target.value; shIdx = 0; renderShelf(); };
  $('#shPrev').onclick = () => shGo(shIdx - 1);
  $('#shNext').onclick = () => shGo(shIdx + 1);
  bindShelfGesture();
  shLayout(false);
}
function shGo(i) {
  const n = shList().length; i = Math.max(0, Math.min(n - 1, i));
  if (i === shIdx) return; shIdx = i; shLayout(true);
  if (navigator.vibrate) try { navigator.vibrate(6); } catch (e) {}
}
function shLayout(anim) {
  const list = shList(), items = $$('#shStage .sh-item'); if (!items.length) return;
  items.forEach((el, i) => {
    const d = i - shIdx, a = Math.abs(d), side = d < 0 ? -1 : 1;
    const x = d === 0 ? 0 : side * (96 + (a - 1) * 24);
    const z = d === 0 ? 130 : -a * 16;
    const r = d === 0 ? 0 : -side * 58;
    const s = d === 0 ? 1.16 : 1;
    el.style.transition = anim ? '' : 'none';
    el.style.transform = `translate3d(calc(-50% + ${x}px), -50%, ${z}px) rotateY(${r}deg) scale(${s})`;
    el.style.zIndex = 200 - a;
    el.style.opacity = a > 7 ? 0 : 1;
    el.style.pointerEvents = a > 7 ? 'none' : 'auto';
    el.classList.toggle('on', d === 0);
  });
  const p = list[shIdx];
  $('#shInfo').innerHTML = `<div><b>${p.name}</b><small>${p.jp} · ${catName(p.cat)}${p.tag ? ' · ' + p.tag : ''}</small></div><button class="sh-go" id="shGo" aria-label="查看">↗</button>`;
  $('#shGo').onclick = () => shOpen(p);
  $('#shNum').textContent = `${String(shIdx + 1).padStart(2, '0')} / ${String(list.length).padStart(2, '0')}`;
  $('#shPrev').disabled = shIdx === 0; $('#shNext').disabled = shIdx === list.length - 1;
}
function shOpen(p) {
  if (p.simple) { addLine({ key: p.id, pid: p.id, qty: 1 }); toast('已加入 ' + p.name); return; }
  openCupPage(p.id);
}
/* 杯架专用：整页奶茶详情（替代底部弹层） */
function openCupPage(id) {
  const p = byId(id); if (!p) return;
  const sel = { size: 0, temp: p.temps[0], sugar: p.defSugar, tops: [], qty: 1 };
  const unit = () => p.price + SIZES[sel.size].p + sel.tops.reduce((s, t) => s + TOPS[t].p, 0);
  const no = String(PRODUCTS.indexOf(p) + 1).padStart(3, '0');
  const grp = (t, g, inner, extra = '') => `<div class="grp"><h4>${t}${extra}</h4><div class="opts" data-g="${g}">${inner}</div></div>`;
  const body = `
    <div class="cp-hero">
      <div class="cp-card"><span class="cp-no">NO.${no}</span>${visual(p)}</div>
      <div class="cp-meta">
        <h2>${p.name}</h2><div class="pjp">${p.jp}</div>
        <div class="cp-tags"><span>${catName(p.cat)}</span>${p.tag ? `<span class="red">${p.tag}</span>` : ''}</div>
        <div class="price"><small>¥</small>${p.price}${p.orig ? `<s>¥${p.orig}</s>` : ''}</div>
      </div>
    </div>
    <div class="cp-note"><div class="cp-lab">01 / NOTES</div><p>${p.desc}</p></div>
    <div class="cp-lab cp-lab2">02 / OPTIONS</div>
    <div class="cp-opts">
      ${grp('杯型', 'size', SIZES.map((s, i) => `<button class="opt ${i === 0 ? 'on' : ''}" data-v="${i}">${s.n}${s.p ? `<small>+¥${s.p}</small>` : ''}</button>`).join(''))}
      ${grp('温度', 'temp', p.temps.map((t, i) => `<button class="opt ${i === 0 ? 'on' : ''}" data-v="${t}">${t}</button>`).join(''))}
      ${grp('甜度', 'sugar', SUGARS.map((t, i) => `<button class="opt ${i === p.defSugar ? 'on' : ''}" data-v="${i}">${t}</button>`).join(''))}
      ${p.tops.length ? grp('加料', 'tops', p.tops.map(t => `<button class="opt" data-v="${t}">${TOPS[t].n}<small>+¥${TOPS[t].p}</small></button>`).join(''), '<small>可多选</small>') : ''}
    </div>`;
  const footer = `<div class="price" id="cpPrice" style="flex:1"></div>
    <div class="stepper"><button id="cpM">−</button><span id="cpQ">1</span><button class="plus" id="cpP">+</button></div>
    <button class="btn" id="cpAdd">加入购物车</button>`;
  openOv('奶茶详情', body, { footer, onMount: (el, api) => {
    const upd = () => { $('#cpPrice', el).innerHTML = `<small>¥</small>${unit() * sel.qty}`; $('#cpQ', el).textContent = sel.qty; };
    $$('.opts', el).forEach(g => g.onclick = e => {
      const b = e.target.closest('.opt'); if (!b) return; const k = g.dataset.g, v = b.dataset.v;
      if (k === 'tops') { const i = sel.tops.indexOf(v); i >= 0 ? sel.tops.splice(i, 1) : sel.tops.push(v); b.classList.toggle('on'); }
      else { $$('.opt', g).forEach(x => x.classList.remove('on')); b.classList.add('on'); sel[k] = (k === 'temp') ? v : +v; }
      upd();
    });
    $('#cpM', el).onclick = () => { sel.qty = Math.max(1, sel.qty - 1); upd(); };
    $('#cpP', el).onclick = () => { sel.qty = Math.min(20, sel.qty + 1); upd(); };
    $('#cpAdd', el).onclick = () => {
      const tops = [...sel.tops].sort();
      addLine({ key: [p.id, sel.size, sel.temp, sel.sugar, tops.join('+')].join('|'), pid: p.id, size: sel.size, temp: sel.temp, sugar: sel.sugar, tops, qty: sel.qty });
      api.close(); toast('已加入购物车');
    };
    upd();
  } });
}
function bindShelfGesture() {
  const st = $('#shStage'); let down = null, moved = false;
  st.onpointerdown = e => {
    const it = e.target.closest('.sh-item');
    down = { x: e.clientX, last: e.clientX, i: it ? +it.dataset.i : -1, id: e.pointerId }; moved = false;
  };
  st.onpointermove = e => {
    if (!down) return;
    if (!moved && Math.abs(e.clientX - down.x) > 8) { moved = true; try { st.setPointerCapture(down.id); } catch (_) {} }
    const dx = e.clientX - down.last;
    if (Math.abs(dx) >= 34) { shGo(shIdx + (dx < 0 ? 1 : -1)); down.last = e.clientX; }
  };
  st.onpointerup = () => {
    if (!down) return; const d = down, was = moved; down = null;
    if (was || d.i < 0) return;
    if (d.i === shIdx) shOpen(shList()[d.i]); else shGo(d.i);
  };
  st.onpointercancel = () => { down = null; };
  let wt = 0;
  st.onwheel = e => { e.preventDefault(); const t = Date.now(); if (t - wt < 120) return; wt = t; shGo(shIdx + ((e.deltaX || e.deltaY) > 0 ? 1 : -1)); };
}

/* ---------- 搜索 ---------- */
function openSearch() {
  openOv(`<div class="sbar">${ic('search')}<input id="sIn" placeholder="搜索饮品，如 草莓、乌龙、拿铁" autocomplete="off"></div>`, '<div id="sRes"></div>', {
    onMount: (ov, api) => {
      const inp = $('#sIn', ov), res = $('#sRes', ov);
      const draw = () => {
        const k = inp.value.trim().toLowerCase();
        const list = k ? PRODUCTS.filter(p => (p.name + p.jp + p.desc).toLowerCase().includes(k)) : PRODUCTS.filter(p => p.hot);
        res.innerHTML = `<div style="padding:4px 14px">${k ? '' : '<div class="cat-h"><b>大家都在喝</b><i>HOT</i></div>'}${list.map(prodHTML).join('') || '<div class="empty">没有找到相关饮品</div>'}</div>`;
      };
      inp.oninput = draw; draw(); setTimeout(() => inp.focus(), 300);
      res.onclick = e => {
        const t = e.target.closest('[data-plus],[data-minus],[data-open],.prod'); if (!t) return;
        if (t.dataset.plus || t.dataset.minus) { bindProdClick(e); draw(); return; }
        bindProdClick(e);
      };
    }
  });
}

/* ---------- 商品规格 ---------- */
function openProduct(id) {
  const p = byId(id); if (!p) return;
  if (p.simple) { addLine({ key: p.id, pid: p.id, qty: 1 }); toast('已加入 ' + p.name); return; }
  const sel = { size: 0, temp: p.temps[0], sugar: p.defSugar, tops: [], qty: 1 };
  const unit = () => p.price + SIZES[sel.size].p + sel.tops.reduce((s, t) => s + TOPS[t].p, 0);
  openSheet(`<button class="sh-x">${ic('x')}</button>
    <div class="sh-b" style="padding-top:16px">
      <div class="pd-top"><div class="tile">${visual(p)}</div><div class="pinfo"><div class="pname">${p.name}${p.tag ? `<span class="ptag">${p.tag}</span>` : ''}</div><div class="pjp">${p.jp}</div><div class="pdesc">${p.desc}</div></div></div>
      <div class="grp"><h4>杯型</h4><div class="opts" data-g="size">${SIZES.map((s, i) => `<button class="opt ${i === 0 ? 'on' : ''}" data-v="${i}">${s.n}${s.p ? `<small>+¥${s.p}</small>` : ''}</button>`).join('')}</div></div>
      <div class="grp"><h4>温度</h4><div class="opts" data-g="temp">${p.temps.map((t, i) => `<button class="opt ${i === 0 ? 'on' : ''}" data-v="${t}">${t}</button>`).join('')}</div></div>
      <div class="grp"><h4>甜度</h4><div class="opts" data-g="sugar">${SUGARS.map((t, i) => `<button class="opt ${i === p.defSugar ? 'on' : ''}" data-v="${i}">${t}</button>`).join('')}</div></div>
      ${p.tops.length ? `<div class="grp"><h4>加料<small>可多选</small></h4><div class="opts" data-g="tops">${p.tops.map(t => `<button class="opt" data-v="${t}">${TOPS[t].n}<small>+¥${TOPS[t].p}</small></button>`).join('')}</div></div>` : ''}
    </div>
    <div class="sh-f"><div style="flex:1"><div class="price" id="pdPrice"></div></div>
      <div class="stepper"><button id="pdM">−</button><span id="pdQ">1</span><button class="plus" id="pdP">+</button></div>
      <button class="btn" id="pdAdd">加入购物车</button></div>`, {
    onMount: (el, api) => {
      const upd = () => { $('#pdPrice', el).innerHTML = `<small>¥</small>${unit() * sel.qty}`; $('#pdQ', el).textContent = sel.qty; };
      $$('.opts', el).forEach(g => g.onclick = e => {
        const b = e.target.closest('.opt'); if (!b) return; const k = g.dataset.g, v = b.dataset.v;
        if (k === 'tops') { const i = sel.tops.indexOf(v); i >= 0 ? sel.tops.splice(i, 1) : sel.tops.push(v); b.classList.toggle('on'); }
        else { $$('.opt', g).forEach(x => x.classList.remove('on')); b.classList.add('on'); sel[k] = (k === 'temp') ? v : +v; }
        upd();
      });
      $('#pdM', el).onclick = () => { sel.qty = Math.max(1, sel.qty - 1); upd(); };
      $('#pdP', el).onclick = () => { sel.qty = Math.min(20, sel.qty + 1); upd(); };
      $('#pdAdd', el).onclick = () => {
        const tops = [...sel.tops].sort();
        addLine({ key: [p.id, sel.size, sel.temp, sel.sugar, tops.join('+')].join('|'), pid: p.id, size: sel.size, temp: sel.temp, sugar: sel.sugar, tops, qty: sel.qty });
        api.close(); toast('已加入购物车');
      };
      upd();
    }
  });
}

/* ---------- 购物车 ---------- */
function crowHTML(l) {
  const p = byId(l.pid);
  return `<div class="crow"><div class="tile">${visual(p)}</div><div class="ci"><b>${p.name}</b>${lineSpec(l) ? `<small>${lineSpec(l)}</small>` : '<small>&nbsp;</small>'}<div class="price"><small>¥</small>${lineUnit(l)}</div></div>
    <div class="stepper"><button data-k="${l.key}" data-d="-1">−</button><span>${l.qty}</span><button class="plus" data-k="${l.key}" data-d="1">+</button></div></div>`;
}
function openCart() {
  if (!cartCount()) return;
  openSheet(`<button class="sh-x">${ic('x')}</button><div class="sh-h">已选商品 <small style="font-size:12px;color:#8b8880;font-weight:600">共 <span id="ctN"></span> 件</small></div>
    <div class="sh-b" id="ctB"></div>
    <div class="sh-f"><button class="btn ghost sm" id="ctClr">清空</button><div style="flex:1;text-align:right;font-size:12px;color:#3a3936">合计 <b id="ctT" style="font-size:21px;color:#111"></b></div><button class="btn" id="ctGo">去结算</button></div>`, {
    onMount: (el, api) => {
      const draw = () => {
        if (!cartCount()) { api.close(); return; }
        $('#ctN', el).textContent = cartCount(); $('#ctT', el).textContent = money(cartSub());
        $('#ctB', el).innerHTML = S.cart.map(crowHTML).join('');
      };
      $('#ctB', el).onclick = e => { const b = e.target.closest('[data-k]'); if (b) { changeQty(b.dataset.k, +b.dataset.d); draw(); } };
      $('#ctClr', el).onclick = () => { S.cart = []; save(); refreshAll(); api.close(); };
      $('#ctGo', el).onclick = () => { api.close(); openCheckout(); };
      draw();
    }
  });
}

/* ---------- 结算 ---------- */
const T_PICK = ['尽快取餐 · 约10分钟', '15分钟后', '30分钟后', '1小时后'];
const T_DELI = ['尽快送达 · 约35分钟', '45分钟后', '1小时后'];
function calcCk(ck) {
  const sub = cartSub(), delivery = S.mode === 'delivery';
  const fee = delivery ? (sub >= 40 ? 0 : 3) : 0;
  const ok = S.coupons.filter(c => !c.used && sub >= c.min);
  let cp = null;
  if (ck.coupon === 'auto') cp = ok.sort((a, b) => b.off - a.off)[0] || null;
  else if (ck.coupon !== 'none') cp = ok.find(c => c.id === ck.coupon) || null;
  const cpOff = cp ? Math.min(cp.off, sub) : 0;
  const base = sub - cpOff;
  const ptsOff = ck.usePts ? Math.max(0, Math.min(Math.floor(S.points / 100), Math.floor(base * 0.3))) : 0;
  const total = Math.round((base - ptsOff + fee) * 100) / 100;
  return { sub, fee, cp, cpOff, ptsOff, total, okN: ok.length, delivery };
}
function openCheckout() {
  if (!cartCount()) { toast('购物车还是空的'); return; }
  const ck = { coupon: 'auto', usePts: true, pay: 'wx', time: 0, note: '', phone: S.phone };
  closeAll();
  openOv('确认订单', '<div id="ckB"></div>', {
    footer: `<div class="tot">应付合计<br><b id="ckT"></b></div><button class="btn" id="ckGo" style="padding:13px 30px">提交订单</button>`,
    onMount: (ov, api) => {
      const body = $('#ckB', ov);
      const draw = () => {
        const c = calcCk(ck), st = STORES[S.store], ad = S.addrs.find(a => a.id === S.addrSel);
        const times = c.delivery ? T_DELI : T_PICK; if (ck.time >= times.length) ck.time = 0;
        body.innerHTML = `
        <div class="blk panel"><div class="seg" id="ckSeg" style="width:100%;margin-bottom:12px"><button data-m="pickup" style="flex:1;padding:8px">到店自取</button><button data-m="delivery" style="flex:1;padding:8px">外卖配送</button></div>
          ${c.delivery
            ? `<button class="kv" id="ckAddr"><span>收货地址</span><em style="color:#111;font-weight:800">${ad ? `${ad.addr}<br><span style="font-weight:600;color:#8b8880">${ad.name} ${ad.phone}</span>` : '请选择或添加收货地址'}</em>${ic('chev', 's14')}</button>`
            : `<div class="kv"><span>取餐门店</span><em style="color:#111;font-weight:800">${st.n}</em></div>
               <div class="kv"><span>预留手机</span><em><input id="ckPh" value="${ck.phone}" placeholder="选填 · 便于取餐联系" inputmode="tel" maxlength="11" style="border:0;background:none;text-align:right;width:100%;font-size:13px"></em></div>`}
          <button class="kv" id="ckTime"><span>${c.delivery ? '送达时间' : '取餐时间'}</span><em style="color:#111;font-weight:800">${times[ck.time]}</em>${ic('chev', 's14')}</button></div>
        <div class="blk panel"><h3>商品清单 <small style="font-weight:600;color:#8b8880">${cartCount()} 件</small></h3>${S.cart.map(crowHTML).join('')}</div>
        <div class="blk panel"><button class="kv" id="ckCp"><span>优惠券</span><em class="${c.cp ? 'neg' : ''}">${c.cp ? `${c.cp.name} -${money(c.cpOff)}` : (c.okN ? `${c.okN} 张可用` : '暂无可用')}</em>${ic('chev', 's14')}</button>
          <div class="kv"><span>积分抵扣 <small style="color:#8b8880;font-weight:600">(100分=¥1)</small></span><em class="${c.ptsOff ? 'neg' : ''}" style="flex:none">${c.ptsOff ? `-${money(c.ptsOff)}` : '本单不可用'}</em><span class="sw ${ck.usePts ? 'on' : ''}" id="ckPts" style="margin-left:10px"></span></div>
          <div class="kv"><span>备注</span><em><input id="ckNote" value="${ck.note.replace(/"/g, '&quot;')}" placeholder="口味、餐具等需求" maxlength="30" style="border:0;background:none;text-align:right;width:100%;font-size:13px"></em></div></div>
        <div class="blk panel"><h3>支付方式 <small style="font-weight:600;color:#8b8880">模拟支付 · 不扣真钱</small></h3>
          <button class="pay ${ck.pay === 'wx' ? 'on' : ''}" data-p="wx"><b>微</b>微信支付<i></i></button>
          <button class="pay ${ck.pay === 'ali' ? 'on' : ''}" data-p="ali"><b>支</b>支付宝<i></i></button></div>
        <div class="blk panel"><div class="kv" style="border:0"><span>商品小计</span><b>${money(c.sub)}</b></div>
          ${c.delivery ? `<div class="kv"><span>配送费</span><b>${c.fee ? money(c.fee) : '免配送费'}</b></div>` : ''}
          ${c.cpOff ? `<div class="kv"><span>优惠券</span><b class="neg">-${money(c.cpOff)}</b></div>` : ''}
          ${c.ptsOff ? `<div class="kv"><span>积分抵扣</span><b class="neg">-${money(c.ptsOff)}</b></div>` : ''}
          <div class="kv big"><span style="color:#111">合计</span><b>${money(c.total)}</b></div></div>`;
        $('#ckT', ov).textContent = money(c.total);
        $$('#ckSeg button', body).forEach(b => b.classList.toggle('on', b.dataset.m === S.mode));
        $$('#ckSeg button', body).forEach(b => b.onclick = () => { S.mode = b.dataset.m; save(); updateSeg(); draw(); });
        $('#ckTime', body).onclick = () => chooseOne('选择' + (c.delivery ? '送达' : '取餐') + '时间', times, ck.time, i => { ck.time = i; draw(); });
        const ph = $('#ckPh', body); if (ph) ph.oninput = () => ck.phone = ph.value.replace(/\D/g, '');
        $('#ckNote', body).oninput = e => ck.note = e.target.value;
        $('#ckAddr', body) && ($('#ckAddr', body).onclick = () => pickAddress(() => draw()));
        $('#ckCp', body).onclick = () => pickCoupon(ck, () => draw());
        $('#ckPts', body).onclick = () => { ck.usePts = !ck.usePts; draw(); };
        $$('.pay', body).forEach(b => b.onclick = () => { ck.pay = b.dataset.p; draw(); });
        $$('.crow .stepper button', body).forEach(b => b.onclick = () => { changeQty(b.dataset.k, +b.dataset.d); if (!cartCount()) { api.close(); return; } draw(); });
      };
      $('#ckGo', ov).onclick = () => {
        const c = calcCk(ck);
        if (c.delivery && c.sub < 15) { toast('外卖满 ¥15 起送'); return; }
        if (c.delivery && !S.addrs.find(a => a.id === S.addrSel)) { toast('请先添加收货地址'); return; }
        S.phone = ck.phone || S.phone; save();
        paySheet(ck, c, api);
      };
      draw();
    }
  });
}
function chooseOne(title, arr, cur, cb) {
  openSheet(`<button class="sh-x">${ic('x')}</button><div class="sh-h">${title}</div><div class="sh-b">${arr.map((t, i) => `<button class="pay ${i === cur ? 'on' : ''}" data-i="${i}">${t}<i></i></button>`).join('')}</div>`, {
    onMount: (el, api) => $$('.pay', el).forEach(b => b.onclick = () => { cb(+b.dataset.i); api.close(); })
  });
}
function pickCoupon(ck, cb) {
  const sub = cartSub();
  openSheet(`<button class="sh-x">${ic('x')}</button><div class="sh-h">选择优惠券</div><div class="sh-b">
    ${S.coupons.filter(c => !c.used).map(c => { const ok = sub >= c.min; return `<button class="cp ${ok ? '' : 'dis'} ${ck.coupon === c.id ? 'sel' : ''}" data-id="${c.id}" ${ok ? '' : 'data-no="1"'}><div class="l"><b><small>¥</small>${c.off}</b><span>${c.min ? '满' + c.min + '可用' : '无门槛'}</span></div><div class="r"><b>${c.name}</b><small>${ok ? c.desc : '还差 ' + money(c.min - sub) + ' 可用'}</small><small>有效期至 ${c.exp}</small></div></button>`; }).join('') || '<div class="empty">暂无优惠券</div>'}
    <button class="btn ghost" id="cpNo" style="width:100%">不使用优惠券</button></div>`, {
    onMount: (el, api) => {
      $$('.cp', el).forEach(b => b.onclick = () => { if (b.dataset.no) { toast('未满足使用条件'); return; } ck.coupon = b.dataset.id; api.close(); cb(); });
      $('#cpNo', el).onclick = () => { ck.coupon = 'none'; api.close(); cb(); };
    }
  });
}
function pickAddress(cb) {
  openSheet(`<button class="sh-x">${ic('x')}</button><div class="sh-h">选择收货地址</div><div class="sh-b">
    ${S.addrs.map(a => `<button class="cp ${a.id === S.addrSel ? 'sel' : ''}" data-id="${a.id}" style="display:block;padding:12px 14px"><b style="font-size:14px">${a.addr}</b><small style="display:block;font-size:12px;color:#8b8880;margin-top:3px">${a.name} ${a.phone}</small></button>`).join('')}
    <button class="btn" id="adNew" style="width:100%">+ 新增地址</button></div>`, {
    onMount: (el, api) => {
      $$('.cp', el).forEach(b => b.onclick = () => { S.addrSel = b.dataset.id; save(); api.close(); cb(); });
      $('#adNew', el).onclick = () => { api.close(); editAddress(null, cb); };
    }
  });
}
function editAddress(id, cb) {
  const a = S.addrs.find(x => x.id === id) || { name: '', phone: '', addr: '' };
  openSheet(`<button class="sh-x">${ic('x')}</button><div class="sh-h">${id ? '编辑' : '新增'}地址</div><div class="sh-b">
    <input class="field" id="adN" placeholder="收货人" value="${a.name}" maxlength="10">
    <input class="field" id="adP" placeholder="手机号" value="${a.phone}" inputmode="tel" maxlength="11">
    <input class="field" id="adA" placeholder="详细地址（小区/楼栋/门牌）" value="${a.addr}" maxlength="40">
    <button class="btn" id="adOk" style="width:100%">保存</button></div>`, {
    onMount: (el, api) => $('#adOk', el).onclick = () => {
      const n = $('#adN', el).value.trim(), p = $('#adP', el).value.trim(), ad = $('#adA', el).value.trim();
      if (!n || !ad) { toast('请填写收货人和地址'); return; }
      if (id) Object.assign(a, { name: n, phone: p, addr: ad });
      else { const na = { id: 'a' + Date.now(), name: n, phone: p, addr: ad }; S.addrs.push(na); S.addrSel = na.id; }
      save(); api.close(); cb && cb();
    }
  });
}

/* ---------- 支付 & 下单 ---------- */
function paySheet(ck, c, ckApi) {
  const name = ck.pay === 'wx' ? '微信支付' : '支付宝';
  openSheet(`<button class="sh-x">${ic('x')}</button><div class="sh-h">${name}</div><div class="sh-b center">
    <div style="font-size:12px;color:#8b8880;margin-top:4px">EVA 茶研所 · ${STORES[S.store].n}</div>
    <div style="font-size:38px;font-weight:900;margin:8px 0 4px">${money(c.total)}</div>
    <div style="font-size:11px;color:#8b8880;margin-bottom:18px">模拟支付，仅作体验，不会产生任何真实扣款</div>
    <div id="payBox"><button class="btn" id="payOk" style="width:100%">确认支付</button></div></div>`, {
    onMount: (el, api) => $('#payOk', el).onclick = () => {
      $('#payBox', el).innerHTML = '<div class="pay-spin"></div><div style="font-size:13px;font-weight:800">正在同步支付结果…</div>';
      setTimeout(() => { const o = createOrder(ck, c); api.close(); ckApi.close(); setTimeout(() => { go('orders'); openOrder(o.id, true); }, 280); }, 1100);
    }
  });
}
function createOrder(ck, c) {
  S.seq++;
  const o = {
    id: 'o' + Date.now(), no: 'A' + String(S.seq % 1000).padStart(3, '0'), ts: Date.now(), mode: S.mode,
    store: STORES[S.store].n, addr: c.delivery ? S.addrs.find(a => a.id === S.addrSel) : null,
    time: (c.delivery ? T_DELI : T_PICK)[ck.time] || '',
    items: S.cart.map(l => ({ pid: l.pid, spec: lineSpec(l), unit: lineUnit(l), qty: l.qty, line: l })),
    sub: c.sub, fee: c.fee, cpName: c.cp ? c.cp.name : '', cpOff: c.cpOff, cpId: c.cp ? c.cp.id : '', ptsOff: c.ptsOff, ptsUsed: c.ptsOff * 100,
    total: c.total, note: ck.note, pay: ck.pay, status: 'ing',
  };
  S.points -= o.ptsUsed;
  if (c.cp) { const cc = S.coupons.find(x => x.id === c.cp.id); if (cc) cc.used = true; }
  S.cart = []; S.orders.unshift(o); save(); refreshAll();
  return o;
}

/* ================= 订单 ================= */
function stageOf(o) {
  if (o.status === 'done') return 3; if (o.status === 'cancel') return -1;
  const e = (Date.now() - o.ts) / 1000; return e < 8 ? 0 : e < 28 ? 1 : 2;
}
const STEPS = { pickup: ['已接单', '制作中', '待取餐', '已完成'], delivery: ['已接单', '制作中', '配送中', '已送达'] };
function stageText(o) {
  const s = stageOf(o);
  if (s < 0) return ['订单已取消', '积分与优惠券已退回。'];
  const d = o.mode === 'delivery';
  return [
    ['商家已接单', '门店已收到你的订单，马上开始制作。'],
    ['饮品制作中', '店员正在手作你的饮品，请稍候…'],
    d ? ['配送中', '骑手正在送往你的驾驶舱。'] : ['请前往取餐', `请到「${o.store}」出示取餐码取餐。`],
    d ? ['已送达', '祝你用餐愉快。'] : ['订单已完成', '感谢光临，期待下次同步。'],
  ][s];
}
let otab = 'ing';
function thumbs(o) {
  return o.items.slice(0, 4).map(i => `<div class="tile">${visual(byId(i.pid))}${i.qty > 1 ? `<em>×${i.qty}</em>` : ''}</div>`).join('') + (o.items.length > 4 ? `<div class="tile" style="font-weight:900">+${o.items.length - 4}</div>` : '');
}
function badgeOf(o) {
  const s = stageOf(o), t = stageText(o)[0];
  return `<span class="badge ${s < 0 ? 'cancel' : s === 3 ? 'done' : 'live'}">${t}</span>`;
}
function renderOrders() {
  const pg = $('#page-orders');
  const list = S.orders.filter(o => otab === 'all' || (stageOf(o) >= 0 && stageOf(o) < 3));
  pg.innerHTML = `<div class="pg-t">我的订单<i>ORDERS</i></div>
    <div class="tabs"><button data-t="ing" class="${otab === 'ing' ? 'on' : ''}">进行中</button><button data-t="all" class="${otab === 'all' ? 'on' : ''}">全部订单</button></div>
    ${list.map(o => `<div class="ocard panel" data-id="${o.id}">
      <div class="o-h"><div>${o.store}<small>${new Date(o.ts).toLocaleString('zh-CN', { hour12: false }).replace(/:\d\d$/, '')} · ${o.mode === 'delivery' ? '外卖' : '自取'}</small></div>${badgeOf(o)}</div>
      <div class="o-th">${thumbs(o)}</div>
      ${stageOf(o) >= 0 && stageOf(o) < 3 ? `<div class="o-code">${o.mode === 'delivery' ? '配送单号' : '取餐码'} <b>${o.no}</b></div>` : ''}
      <div class="o-f"><div class="sum">共 ${o.items.reduce((s, i) => s + i.qty, 0)} 件 · 实付 <b>${money(o.total)}</b></div><button class="btn ghost sm" data-again="${o.id}">再来一单</button></div></div>`).join('')
      || `<div class="empty"><img src="img/asuka-bw.jpg" alt="">${otab === 'ing' ? '没有进行中的订单' : '还没有订单'}<br>去点一杯，同步率+1</div>`}
    <div style="height:20px"></div>`;
  $$('.tabs button', pg).forEach(b => b.onclick = () => { otab = b.dataset.t; renderOrders(); });
  $$('.ocard', pg).forEach(c => c.onclick = e => { const a = e.target.closest('[data-again]'); a ? again(a.dataset.again) : openOrder(c.dataset.id); });
}
function again(id) {
  const o = S.orders.find(x => x.id === id); if (!o) return;
  o.items.forEach(i => { const l = { ...i.line }; if (!byId(l.pid)) return; const ex = S.cart.find(x => x.key === l.key); ex ? ex.qty += l.qty : S.cart.push(l); });
  S.mode = o.mode; save(); go('menu'); refreshAll(); toast('已加入购物车'); setTimeout(openCart, 250);
}
function odHead(o) {
  const s = stageOf(o), [t, d] = stageText(o), labs = STEPS[o.mode];
  return `<div class="od-hero"><h2>${t}</h2><p>${d}${s >= 0 && s < 2 ? '<br>（体验版加速：约 30 秒后可取餐）' : ''}</p>
    ${s >= 0 ? `<div class="steps">${labs.map((l, i) => `<div class="step ${i < s || s === 3 ? 'done' : i === s ? 'cur' : ''}"><i></i>${l}</div>`).join('')}</div>` : ''}</div>
  ${s >= 0 ? `<div class="code panel"><small>${o.mode === 'delivery' ? '配送单号' : '取餐码'}</small><b>${o.no}</b>${s === 3 ? '<span class="stamp pop">DONE</span>' : ''}</div>` : ''}`;
}
function openOrder(id, fresh) {
  const o = S.orders.find(x => x.id === id); if (!o) return;
  let timer;
  const render = (api) => {
    const s = stageOf(o);
    api.body.innerHTML = `<div id="odHead">${odHead(o)}</div>
      <div class="blk panel"><h3>${o.store}</h3>${o.items.map(i => `<div class="crow"><div class="tile">${visual(byId(i.pid))}</div><div class="ci"><b>${byId(i.pid).name}</b><small>${i.spec || '&nbsp;'}</small><div class="price"><small>¥</small>${i.unit}</div></div><b>×${i.qty}</b></div>`).join('')}
        <div style="height:6px"></div>
        <div class="line"><span>商品小计</span><b>${money(o.sub)}</b></div>
        ${o.mode === 'delivery' ? `<div class="line"><span>配送费</span><b>${o.fee ? money(o.fee) : '免配送费'}</b></div>` : ''}
        ${o.cpOff ? `<div class="line"><span>优惠券 · ${o.cpName}</span><b class="red-t">-${money(o.cpOff)}</b></div>` : ''}
        ${o.ptsOff ? `<div class="line"><span>积分抵扣</span><b class="red-t">-${money(o.ptsOff)}</b></div>` : ''}
        <div class="line t"><span>实付款</span><b>${money(o.total)}</b></div></div>
      <div class="blk panel"><h3>订单信息</h3>
        <div class="line"><span>订单编号</span><b>${o.id.slice(1)}</b></div>
        <div class="line"><span>下单时间</span><b>${new Date(o.ts).toLocaleString('zh-CN', { hour12: false })}</b></div>
        <div class="line"><span>${o.mode === 'delivery' ? '送达时间' : '取餐时间'}</span><b>${o.time}</b></div>
        ${o.addr ? `<div class="line"><span>收货信息</span><b style="text-align:right;max-width:70%">${o.addr.addr}<br>${o.addr.name} ${o.addr.phone}</b></div>` : ''}
        <div class="line"><span>支付方式</span><b>${o.pay === 'wx' ? '微信支付' : '支付宝'}（模拟）</b></div>
        ${o.note ? `<div class="line"><span>备注</span><b>${o.note}</b></div>` : ''}</div>
      <div class="acts">${s === 2 ? `<button class="btn" id="odOk">${o.mode === 'delivery' ? '确认收货' : '确认取餐'}</button>` : ''}
        ${s >= 0 && s < 2 ? `<button class="btn ghost" id="odCancel">取消订单</button>` : ''}
        <button class="btn ${s === 2 ? 'ghost' : ''}" id="odAgain">再来一单</button></div>`;
    const ok = $('#odOk', api.body), cn = $('#odCancel', api.body);
    ok && (ok.onclick = () => { o.status = 'done'; const pts = Math.floor(o.total); S.points += pts; o.earned = pts; save(); renderTabbar(); render(api); toast(`订单完成 · 获得 ${pts} 积分`); });
    cn && (cn.onclick = () => {
      openSheet(`<div class="sh-h">确定取消订单？</div><div class="sh-b" style="font-size:13px;color:#3a3936">积分和优惠券会原路退回。</div><div class="sh-f"><button class="btn ghost" id="n1" style="flex:1">再想想</button><button class="btn" id="n2" style="flex:1">确认取消</button></div>`, {
        onMount: (el, a2) => { $('#n1', el).onclick = a2.close; $('#n2', el).onclick = () => {
          o.status = 'cancel'; S.points += o.ptsUsed; if (o.cpId) { const cc = S.coupons.find(x => x.id === o.cpId); if (cc) cc.used = false; }
          save(); a2.close(); renderTabbar(); render(api); toast('订单已取消');
        }; }
      });
    });
    $('#odAgain', api.body).onclick = () => { api.close(); again(o.id); };
  };
  openOv('订单详情', '', {
    onMount: (ov, api) => {
      render(api);
      let last = stageOf(o);
      timer = setInterval(() => {
        const s = stageOf(o);
        if (s !== last) { last = s; render(api); renderTabbar(); } // 阶段变化才整体刷新
        if (s === 3 || s < 0) clearInterval(timer);
      }, 1000);
      if (fresh) toast('下单成功 · 已同步到门店');
    },
    onClose: () => { clearInterval(timer); if (curTab === 'orders') renderOrders(); }
  });
}

/* ================= 我的 ================= */
function renderMe() {
  const lv = levelOf(S.points), pg = $('#page-me'), unused = S.coupons.filter(c => !c.used).length;
  pg.innerHTML = `
  <div class="me-top"><div class="me-bg"><img src="img/asuka-red.jpg" alt=""></div>
    <div class="me-card panel"><div class="me-av"><img src="img/icon.png" alt=""></div>
      <div class="me-nm"><b>${S.nick}</b><small>${lv.name}</small></div>
      <div class="me-stats"><button data-r="pts"><b>${S.points}</b>积分</button><button data-r="cp"><b>${unused}</b>优惠券</button><button data-r="ord"><b>${S.orders.length}</b>订单</button></div></div></div>
  <div class="list panel">
    <button class="row" data-r="cp">${ic('ticket')}<span>我的优惠券</span><em>${unused} 张可用</em>${ic('chev', 'chev')}</button>
    <button class="row" data-r="ex">${ic('gift')}<span>积分兑换</span><em>${S.points} 分</em>${ic('chev', 'chev')}</button>
    <button class="row" data-r="ad">${ic('pin')}<span>收货地址</span><em>${S.addrs.length} 个</em>${ic('chev', 'chev')}</button>
    <button class="row" data-r="gal">${ic('image')}<span>影像档案</span><em>明日香画册</em>${ic('chev', 'chev')}</button>
  </div>
  <div class="list panel">
    <button class="row" data-r="bgm">${ic('music')}<span>背景音乐</span><i class="sw ${S.bgm ? 'on' : ''}" id="meSw"></i></button>
    <button class="row" data-r="nick">${ic('edit')}<span>修改昵称</span>${ic('chev', 'chev')}</button>
    <button class="row" data-r="clr">${ic('trash')}<span>清除本地数据</span>${ic('chev', 'chev')}</button>
  </div>
  <div class="foot">EVA 茶研所 v1.0<br>个人自用练习项目 · 非商业用途</div>`;
  $$('[data-r]', pg).forEach(b => b.onclick = () => meAct(b.dataset.r));
}
function meAct(r) {
  if (r === 'pts' || r === 'ex') return openExchange();
  if (r === 'cp') return openCoupons();
  if (r === 'ord') return go('orders');
  if (r === 'ad') return openAddrs();
  if (r === 'gal') return openGallery();
  if (r === 'bgm') return setBgm(!S.bgm);
  if (r === 'nick') {
    openSheet(`<button class="sh-x">${ic('x')}</button><div class="sh-h">修改昵称</div><div class="sh-b"><input class="field" id="nkI" value="${S.nick}" maxlength="10"><button class="btn" id="nkOk" style="width:100%">保存</button></div>`, {
      onMount: (el, api) => $('#nkOk', el).onclick = () => { const v = $('#nkI', el).value.trim(); if (v) { S.nick = v; save(); renderMe(); } api.close(); }
    }); return;
  }
  if (r === 'clr') {
    openSheet(`<div class="sh-h">清除所有本地数据？</div><div class="sh-b" style="font-size:13px;color:#3a3936">订单、积分、优惠券、地址都会恢复到初始状态。</div><div class="sh-f"><button class="btn ghost" id="c1" style="flex:1">取消</button><button class="btn red" id="c2" style="flex:1">确认清除</button></div>`, {
      onMount: (el, api) => { $('#c1', el).onclick = api.close; $('#c2', el).onclick = () => { try { localStorage.removeItem(KEY); } catch (e) {} S = DEF(); save(); api.close(); renderMenu(); go('home'); toast('已恢复初始状态'); }; }
    });
  }
}
function openCoupons() {
  const draw = () => [...S.coupons].sort((a, b) => a.used - b.used).map(c => `<div class="cp ${c.used ? 'dis' : ''}"><div class="l"><b><small>¥</small>${c.off}</b><span>${c.min ? '满' + c.min + '可用' : '无门槛'}</span></div><div class="r"><b>${c.name}</b><small>${c.used ? '已使用' : c.desc}</small><small>有效期至 ${c.exp}</small></div></div>`).join('');
  openOv('我的优惠券', `<div style="padding:16px">${draw() || '<div class="empty">暂无优惠券</div>'}</div>`);
}
function openExchange() {
  const items = [[200, '满15减3', 15, 3], [500, '满25减8', 25, 8], [1000, '满39减15', 39, 15]];
  openSheet(`<button class="sh-x">${ic('x')}</button><div class="sh-h">积分兑换 <small style="font-size:12px;color:#8b8880;font-weight:600">当前 ${S.points} 分</small></div><div class="sh-b">
    ${items.map((it, i) => `<button class="cp ${S.points < it[0] ? 'dis' : ''}" data-i="${i}"><div class="l"><b><small>¥</small>${it[3]}</b><span>${it[1]}</span></div><div class="r"><b>${it[1]} 优惠券</b><small>需 ${it[0]} 积分</small><small>${S.points < it[0] ? '积分不足' : '点击兑换'}</small></div></button>`).join('')}</div>`, {
    onMount: (el, api) => $$('.cp', el).forEach(b => b.onclick = () => {
      const it = items[+b.dataset.i]; if (S.points < it[0]) { toast('积分不足'); return; }
      S.points -= it[0]; S.coupons.push({ id: 'c' + Date.now(), name: it[1] + '券', desc: '积分兑换 · ' + it[1], min: it[2], off: it[3], exp: '2027-06-30', used: false });
      save(); api.close(); renderMe(); toast('兑换成功');
    })
  });
}
function openAddrs() {
  openOv('收货地址', '<div id="adL" style="padding:16px"></div>', {
    footer: '<button class="btn" id="adAdd" style="flex:1">+ 新增地址</button>',
    onMount: (ov) => {
      const draw = () => {
        $('#adL', ov).innerHTML = S.addrs.map(a => `<div class="cp" style="display:block;padding:12px 14px;border-color:${a.id === S.addrSel ? '#d4202c' : '#111'}"><b style="font-size:14px;font-weight:900">${a.addr}</b><small style="display:block;font-size:12px;color:#8b8880;margin:3px 0 9px">${a.name} ${a.phone}${a.id === S.addrSel ? ' · 默认' : ''}</small>
          <div style="display:flex;gap:8px"><button class="btn ghost sm" data-e="${a.id}">编辑</button><button class="btn ghost sm" data-d="${a.id}">删除</button>${a.id !== S.addrSel ? `<button class="btn ghost sm" data-s="${a.id}">设为默认</button>` : ''}</div></div>`).join('') || '<div class="empty">还没有收货地址</div>';
        $$('[data-e]', ov).forEach(b => b.onclick = () => editAddress(b.dataset.e, draw));
        $$('[data-d]', ov).forEach(b => b.onclick = () => { S.addrs = S.addrs.filter(a => a.id !== b.dataset.d); if (S.addrSel === b.dataset.d) S.addrSel = S.addrs[0] ? S.addrs[0].id : ''; save(); draw(); renderMe(); });
        $$('[data-s]', ov).forEach(b => b.onclick = () => { S.addrSel = b.dataset.s; save(); draw(); });
      };
      $('#adAdd', ov).onclick = () => editAddress(null, () => { draw(); renderMe(); });
      draw();
    }
  });
}
function openGallery() {
  const imgs = ['img/poster.jpg', 'img/asuka-red.jpg', 'img/asuka-cafe.jpg', 'img/asuka-bw.jpg', 'img/asuka-rain.jpg'];
  openOv('影像档案', `<div class="gal">${imgs.map(s => `<button data-s="${s}"><img src="${s}" alt=""></button>`).join('')}</div>`, {
    onMount: ov => $$('[data-s]', ov).forEach(b => b.onclick = () => lightbox(b.dataset.s))
  });
}

/* ================= 背景音乐 ================= */
const bgm = $('#bgm');
function setBgm(on) {
  S.bgm = on; save();
  if (on) bgm.play().catch(() => toast('请再点一次开启音乐')); else bgm.pause();
  if (curTab === 'home') { const sp = $('#hBgm span'); sp && (sp.textContent = on ? 'BGM 开' : 'BGM 关'); }
  const sw = $('#meSw'); sw && sw.classList.toggle('on', on);
}
let bgmKick = false;
document.addEventListener('touchstart', () => { if (!bgmKick && S.bgm) { bgmKick = true; bgm.play().catch(() => {}); } }, { once: true, passive: true });
document.addEventListener('visibilitychange', () => { if (document.hidden) bgm.pause(); else if (S.bgm) bgm.play().catch(() => {}); });

/* ================= 启动 ================= */
renderMenu(); renderHome(); renderTabbar();
let ordSig = '';
setInterval(() => {
  const sig = S.orders.map(o => o.id + stageOf(o)).join(',');
  if (sig !== ordSig) { ordSig = sig; if (curTab === 'orders' && !stack.length) renderOrders(); renderTabbar(); }
}, 2000);
window.addEventListener('load', () => setTimeout(() => { const b = $('#boot'); b.style.opacity = 0; setTimeout(() => b.remove(), 520); }, 1100));
